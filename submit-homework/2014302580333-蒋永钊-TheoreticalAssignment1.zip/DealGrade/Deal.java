package DealGrade;
import java.io.File;
import java.io.IOException;

import jxl.Workbook;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.jsoup.Jsoup;  
import org.jsoup.nodes.Document;  
import org.jsoup.nodes.Element;  
import org.jsoup.select.Elements; 

public class Deal {
	static double GPA=0.0,Average=0.0,Cre=0.0;
	
	static int num=0;//计数有几门
	double gra[];//存储成绩
	//计算GPA
	public void getGPA(double a,double b){
		if(a>=90)
		{
			GPA=GPA+b*4.0;
		}
		else if(a>=85)
		{
			GPA=GPA+b*3.7;
		}
		else if(a>=82)
		{
			GPA=GPA+b*3.3;
		}
		else if(a>=78)
		{
			GPA=GPA+b*3.0;
		}
		else if(a>=75)
		{
			GPA=GPA+b*2.7;
		}
		else if(a>=72)
		{
			GPA=GPA+b*2.3;
		}
		else if(a>=68)
		{
			GPA=GPA+b*2.0;
		}
		else if(a>=64)
		{
			GPA=GPA+b*1.5;
		}
		else if(a>=60)
		{
			GPA=GPA+b*1.0;
		}
		else
		{
			GPA=GPA+b*0.0;
		}
	}
	
    public void get() throws IOException{
    	try{
    		//获取html
    		File input = new File("./Grade.html");
    		Document doc = Jsoup.parse (input, "gb2312","");
    		Element table =doc.getElementsByClass("table").get(0);
    		gra = new double[24];
        	//计算
        	for(int i=0;i<24;i++){
        			Average=Average+Double.parseDouble(table.select("td").get(9+11*i).text())*
        					Double.parseDouble(table.select("td").get(3+11*i).text());
        			Cre=Cre+Double.parseDouble(table.select("td").get(3+11*i).text());
        			getGPA(Double.parseDouble(table.select("td").get(9+11*i).text()),
        					Double.parseDouble(table.select("td").get(3+11*i).text()));
        			gra[num]=Double.parseDouble(table.select("td").get(9+11*i).text());
        			num++;
        			System.out.println("============num changed============"+num);
        	}
        	Average=Average/Cre;
        	GPA=GPA/Cre;
        	//成绩排序
            double tem= 0.0;
    		for(int i=0;i<num;i++)
    		{
    			for(int j=i+1;j<num;j++)
    			{
    				if(gra[j]>gra[i])
    				{
    					tem=gra[j];
    					gra[j]=gra[i];
    					gra[i]=tem;
    				}
    			}
    		}
    		System.out.println("GPA:"+GPA+"\nAverage:"+Average);
        	
    	}
    	catch(Exception e1){
    		e1.printStackTrace();
    	}
    }
    
	public void set(){
		WritableWorkbook writer;

		try {
			
			Document doc = Jsoup.parse (new File("./Grade.html"), "gb2312","");
			Element table =doc.getElementsByClass("table").get(0);
			writer = Workbook.createWorkbook(new File("./DGrade.xls"));
			WritableSheet sheet = writer.createSheet("DGrade", 0);
			
			
			for(int j=0;j<10;j++)
				{
	    			String s = table.select("th").get(j).text();
					sheet.addCell(new jxl.write.Label(j,0,s));
				}
			String ave=""+Average;
			String gpa=""+GPA;
			sheet.addCell(new jxl.write.Label(10,0,"加权平均分"));
			sheet.addCell(new jxl.write.Label(10,1,ave));
			sheet.addCell(new jxl.write.Label(11,0,"加权绩点"));
			sheet.addCell(new jxl.write.Label(11,1,gpa));	
				for(int i=0;i<24;i++)
				{
					for(int j=0;j<24;j++){
						double grade=Double.parseDouble(table.select("td").get(9+11*j).text());
						if(grade==gra[i]){
							for(int k=0;k<10;k++)
							{
								String s = table.select("td").get(k+11*j).text();
								sheet.addCell(new jxl.write.Label(k, i+1, s));
							}
						}
						
					}
							
							
						
						
				}
			
			writer.write();
			writer.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

    }
}
