package DealGrade;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class MainGUI extends JFrame { 
	double GPA=0.0,Average=0.0,Cre=0.0;
	int num=0;//计数有几门
	double gra[];//存储成绩
	private JScrollPane scrollPane;
	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null; // 创建面板对象
	private JTextArea jTextArea = null; // 创建文本域对象
	private JPanel controlPanel = null; // 创建面板对象
	private JButton openButton = null; // 创建按钮对象
	private JButton closeButton = null; // 创建按钮对象
	private String con;                //控制输出
	static Deal deal;
	
	private JTextArea getJTextArea() {
		if (jTextArea == null) {
			jTextArea = new JTextArea();
		}
		return jTextArea;
	}
	
	private JPanel getControlPanel() {
		if (controlPanel == null) {
			FlowLayout flowLayout = new FlowLayout();
			flowLayout.setVgap(1);
			controlPanel = new JPanel();
			controlPanel.setLayout(flowLayout);
			controlPanel.add(getOpenButton(), null);
			controlPanel.add(getCloseButton(), null);
		}
		return controlPanel;
	}

	public MainGUI() {
		super();
		initialize();
	}
	
	private void initialize() {
		this.setSize(300, 200);
		this.setContentPane(getJContentPane());
		this.setTitle("DealGrade");
	}
	
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getScrollPane(), BorderLayout.CENTER);
			jContentPane.add(getControlPanel(), BorderLayout.SOUTH);
		}
		return jContentPane;
	}

	protected JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getJTextArea());
		}
		return scrollPane;
	}
	
	private JButton getOpenButton() {
		if (openButton == null) {
			openButton = new JButton();
			openButton.setText("读取成绩"); 
			openButton
					.addActionListener(new java.awt.event.ActionListener() {
					
						public void actionPerformed(ActionEvent e) {
							try {
								deal.get();
								con="读取成绩";
								jTextArea.setText(con);
							} catch (IOException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}
						}
					});
		}
		return openButton;
	}
	
	private JButton getCloseButton() {
		if (closeButton == null) {
			closeButton = new JButton();
			closeButton.setText("处理成绩");
			closeButton
					.addActionListener(new java.awt.event.ActionListener() {
						
						public void actionPerformed(ActionEvent e) {
							con="处理成绩";
							jTextArea.setText(con);
							deal.set();
							
							
						}
					});
		}
		return closeButton;
	}
	
	
	
	public static void main(String[] args) { 
		MainGUI thisClass = new MainGUI(); // 创建本类对象
		thisClass.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		thisClass.setVisible(true); // 设置该窗体为显示状态
		
		deal = new Deal();
		
	}
	
}
